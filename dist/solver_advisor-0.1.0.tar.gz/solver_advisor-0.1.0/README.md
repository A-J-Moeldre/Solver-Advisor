Solver Advisor
AI‑powered matrix diagnostics and solver recommendations for scientific computing

Solver Advisor is a lightweight analysis tool designed to inspect sparse matrices from scientific simulations (FEM, CFD, optimization, power systems, structural mechanics, etc.) and automatically recommend suitable iterative solvers and preconditioners.

It analyzes matrix structure, symmetry, SPD‑properties, block patterns, condition number, and spectral characteristics using Lanczos iterations.
The tool provides actionable solver recommendations such as CG, GMRES, MINRES, and preconditioners like Jacobi, ILU, SSOR, or Multigrid.

Features
Matrix loading (.mtx, .csv, .npy, .npz)

Symmetry detection

SPD (symmetric positive definite) test

Block‑structure detection

Condition number estimation

Largest/smallest eigenvalue estimation

Lanczos spectrum approximation

Solver recommendation (CG, GMRES, MINRES)

Preconditioner recommendation (Jacobi, SSOR, ILU, Multigrid)

CLI interface

GUI interface (Tkinter)

SuiteSparse matrix downloader (Python script)

Project Structure
Kood
solver-advisor/
│
├── solver_advisor/
│   ├── io.py               # Matrix loading utilities
│   ├── analysis.py         # Symmetry, SPD, block detection
│   ├── spectrum.py         # Eigenvalue & Lanczos routines
│   ├── diagnostics.py      # Solver & preconditioner logic
│   ├── run.py              # High-level execution wrapper
│
├── gui/
│   ├── app.py              # Tkinter GUI
│
├── cli/
│   ├── main.py             # CLI entry point
│
├── matrices/               # Downloaded matrices
│
├── tools/
│   ├── download_matrices.py # SuiteSparse downloader
│
├── tests/
│   ├── test_symmetry.py
│   ├── test_spd.py
│
└── README.md
Installation
Clone the repository:

Kood
git clone https://github.com/<your-username>/solver-advisor
cd solver-advisor
Install in editable mode:

Kood
pip install -e .
This makes the solver-advisor CLI command available system‑wide.

Usage
CLI
Analyze a matrix directly from the terminal:

Kood
solver-advisor matrices/example.mtx
Example output:

Kood
Form: (5000, 5000)
Symmetry: True
SPD: True
Block structure: False
Condition number: 1.2e7
Solver: CG
Preconditioner: ILU/Multigrid
GUI
Start the graphical interface:

Kood
python gui/app.py
The GUI allows you to:

Select matrices from the matrices/ folder

Run full diagnostics

View solver recommendations

Inspect eigenvalues, condition number, SPD status, block structure, etc.

Downloading Matrices (SuiteSparse)
Use the provided script to download real-world sparse matrices:

Kood
python tools/download_matrices.py
This downloads and extracts matrices from the SuiteSparse Matrix Collection into the matrices/ directory.

Example Matrix
You can generate a small example matrix:

python
from solver_advisor.io import create_example_matrix
create_example_matrix()
This creates matrices/example.mtx.

Requirements
Python 3.10+

NumPy

SciPy

ssgetpy

Tkinter (included with most Python installations)

License
MIT License (or whichever you choose)

Author
Allar‑Joel Möldre  
Numerical Analysis • HPC • Solver Diagnostics

Future Work
AMG preconditioner integration

PETSc backend support

Web‑based GUI

Matrix pattern visualization

Solver performance prediction

Automatic preconditioner tuning